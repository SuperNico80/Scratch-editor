// 1. Incluir la librería Keypad (Para el Header)
newBlock(
  "includeKeypad",
  "Include this library",
  [],
  "#ff9800", // Color naranja brillante para la categoría Keypad
  "This block includes this library to your sketch.",
  ""
);

// 2. Configurar el teclado matricial globalmente (Para el Header)
// Asumimos una matriz estándar de 4x4 para mantener el bloque amigable
newBlock(
  "newKeypad",
  "Configure 4x4 Keypad named %1 with Row pins: R1:%2 R2:%3 R3:%4 R4:%5 Col pins: C1:%6 C2:%7 C3:%8 C4:%9",
  [
    { "type": "input_value", "name": "keypadname" },
    // Pines de Filas (R1-R4)
    { "type": "field_dropdown", "name": "R1", "options": [["2","P2"],["3","P3"],["4","P4"],["5","P5"],["6","P6"],["7","P7"],["8","P8"],["9","P9"],["10","P10"],["11","P11"],["12","P12"],["13","P13"]] },
    { "type": "field_dropdown", "name": "R2", "options": [["2","P2"],["3","P3"],["4","P4"],["5","P5"],["6","P6"],["7","P7"],["8","P8"],["9","P9"],["10","P10"],["11","P11"],["12","P12"],["13","P13"]] },
    { "type": "field_dropdown", "name": "R3", "options": [["2","P2"],["3","P3"],["4","P4"],["5","P5"],["6","P6"],["7","P7"],["8","P8"],["9","P9"],["10","P10"],["11","P11"],["12","P12"],["13","P13"]] },
    { "type": "field_dropdown", "name": "R4", "options": [["2","P2"],["3","P3"],["4","P4"],["5","P5"],["6","P6"],["7","P7"],["8","P8"],["9","P9"],["10","P10"],["11","P11"],["12","P12"],["13","P13"]] },
    // Pines de Columnas (C1-C4)
    { "type": "field_dropdown", "name": "C1", "options": [["2","P2"],["3","P3"],["4","P4"],["5","P5"],["6","P6"],["7","P7"],["8","P8"],["9","P9"],["10","P10"],["11","P11"],["12","P12"],["13","P13"]] },
    { "type": "field_dropdown", "name": "C2", "options": [["2","P2"],["3","P3"],["4","P4"],["5","P5"],["6","P6"],["7","P7"],["8","P8"],["9","P9"],["10","P10"],["11","P11"],["12","P12"],["13","P13"]] },
    { "type": "field_dropdown", "name": "C3", "options": [["2","P2"],["3","P3"],["4","P4"],["5","P5"],["6","P6"],["7","P7"],["8","P8"],["9","P9"],["10","P10"],["11","P11"],["12","P12"],["13","P13"]] },
    { "type": "field_dropdown", "name": "C4", "options": [["2","P2"],["3","P3"],["4","P4"],["5","P5"],["6","P6"],["7","P7"],["8","P8"],["9","P9"],["10","P10"],["11","P11"],["12","P12"],["13","P13"]] }
  ],
  "#ff9800",
  "Defines a new global 4x4 Keypad matrix with customized pin layout.",
  ""
);

// 3. Bloque Reportero: Obtener tecla presionada (Para usar en forever o dentro de un IF)
newBlock(
  "readKeypad",
  "Get pressed key from Keypad %1",
  [
    { "type": "input_value", "name": "keypadname" }
  ],
  "#ff9800",
  "Returns the char of the currently pressed key (returns 0 or '\\0' if none).",
  "",
  true, // useEvent = false
  true   // useVarReporter = true (Retorna un caracter/texto atómico)
);