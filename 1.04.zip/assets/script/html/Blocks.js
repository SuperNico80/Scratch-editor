newBlock(
  "settype",
  "Set type to %1", // Removed the extra %1 since newBlock adds it automatically
  [
    {
      type: "field_dropdown",
      name: "type",
      options: [["!doctype html", "!doctype html"]],
    },
  ],
  "#00ddff",
  "Defines the document type.",
  "",
);
newBlock(
  "html",
  "html %1", // Removed the extra %1 since newBlock adds it automatically
  [
    {
      type: "input_statement",
      name: "con",
    },
  ],
  "#00ddff",
  "A tag.",
  "",
);
newBlock(
  "head",
  "head %1", // Removed the extra %1 since newBlock adds it automatically
  [
    {
      type: "input_statement",
      name: "con",
    },
  ],
  "#00ddff",
  "A tag.",
  "",
);
newBlock(
  "title",
  "title %1", // Removed the extra %1 since newBlock adds it automatically
  [
    {
      type: "input_statement",
      name: "con",
    },
  ],
  "#00ddff",
  "A tag.",
  "",
);
newBlock(
  "body",
  "body %1", // Removed the extra %1 since newBlock adds it automatically
  [
    {
      type: "input_statement",
      name: "con",
    },
  ],
  "#00ddff",
  "A tag.",
  "",
);

