const map = {
  contents: [
    {
      kind: "category",
      name: "Headers",
      colour: "#00ddff",
      contents: [
        {
          kind: "block",
          type: "settype"
        },
        {
          kind: "block",
          type: "html"
        }
      ]
    },
  ],
};
