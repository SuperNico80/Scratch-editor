"use strict";


/* =========================================================
   RUTAS
========================================================= */

/*
    script.js está en:

    assets/script/script.js

    Por eso, para llegar a:

    assets/img/svg/blocks/

    solamente hay que subir desde "script" hasta "assets"
    y entrar en "img".
*/

const BLOCKS_PATH = "../assets/img/svg/blocks/";


/* =========================================================
   CONFIGURACIÓN DE CATEGORÍAS
========================================================= */

const CATEGORY_COLORS = {
    html: "#fcba03",
    javascript: "#fcf403",
    css: "#9403fc",
    functions: "#fc7703",
    groups: "#fc5603",
    cssFunctions: "#03fc45",
    myBlocks: "#fc038c"
};


/* =========================================================
   BIBLIOTECA DE BLOQUES
========================================================= */

const SVG_LIBRARY = {

    html: {

        tags: [

            {
                id: "html",
                name: "HTML",
                file: "Html.svg",

                action: "html",

                options: "",
                dropdowns: 0,

                isc: true
            }

        ]

    },


    javascript: {

        functions: [

            {
                id: "settypeto",
                name: "Set type to",

                file: "Settypeto.svg",

                action: "setTypeTo",

                options: "const|let|var",

                dropdowns: 1,

                isc: false
            }

        ]

    },


    css: {

        groups: [],

        functions: []

    }

};


/* =========================================================
   ESTADO
========================================================= */

const state = {

    language: "html",

    blocks: new Map(),

    nextBlockId: 1,

    selectedBlock: null,

    deleteMode: false,

    myBlocks: [],

    dragging: null,

    editingBlock: null

};


/* =========================================================
   ELEMENTOS
========================================================= */

const elements = {

    languageSelect:
        document.getElementById("languageSelect"),

    categories:
        document.getElementById("categories"),

    workspace:
        document.getElementById("workspace"),

    workspaceEmpty:
        document.getElementById("workspaceEmpty"),

    codeOutput:
        document.getElementById("codeOutput"),

    clearButton:
        document.getElementById("clearButton"),

    generateButton:
        document.getElementById("generateButton"),

    copyButton:
        document.getElementById("copyButton"),

    deleteModeButton:
        document.getElementById("deleteModeButton"),

    formatCodeButton:
        document.getElementById("formatCodeButton"),

    myBlockModal:
        document.getElementById("myBlockModal"),

    myBlockName:
        document.getElementById("myBlockName"),

    myBlockColor:
        document.getElementById("myBlockColor"),

    myBlockArguments:
        document.getElementById("myBlockArguments"),

    addArgumentButton:
        document.getElementById("addArgumentButton"),

    cancelMyBlock:
        document.getElementById("cancelMyBlock"),

    createMyBlock:
        document.getElementById("createMyBlock"),

    blockEditModal:
        document.getElementById("blockEditModal"),

    blockEditContent:
        document.getElementById("blockEditContent"),

    cancelBlockEdit:
        document.getElementById("cancelBlockEdit"),

    saveBlockEdit:
        document.getElementById("saveBlockEdit")

};


/* =========================================================
   UTILIDADES
========================================================= */

function escapeHtml(value) {

    return String(value)
        .replaceAll("&", "&amp;")
        .replaceAll("<", "&lt;")
        .replaceAll(">", "&gt;")
        .replaceAll('"', "&quot;")
        .replaceAll("'", "&#039;");

}


function createId() {

    return "block_" + state.nextBlockId++;

}


function parseOptions(value) {

    if (!value) {
        return [];
    }

    return value
        .split("|")
        .map(item => item.trim())
        .filter(Boolean);

}


function getBlockPath(language, category, file) {

    return (
        BLOCKS_PATH +
        encodeURIComponent(language) +
        "/" +
        encodeURIComponent(category) +
        "/" +
        encodeURIComponent(file)
    );

}


function setSvgMetadata(svg, data) {

    if (!svg) {
        return;
    }

    svg.dataset.action = data.action || "";
    svg.dataset.options = data.options || "";
    svg.dataset.dropdowns = String(data.dropdowns || 0);
    svg.dataset.isc = String(Boolean(data.isc));

}


/* =========================================================
   INICIO
========================================================= */

document.addEventListener("DOMContentLoaded", () => {

    initializeEvents();

    renderPalette();

    updateEmptyState();

    generateCode();

});


/* =========================================================
   EVENTOS
========================================================= */

function initializeEvents() {

    elements.languageSelect.addEventListener(
        "change",
        changeLanguage
    );


    elements.clearButton.addEventListener(
        "click",
        clearWorkspace
    );


    elements.generateButton.addEventListener(
        "click",
        generateCode
    );


    elements.copyButton.addEventListener(
        "click",
        copyCode
    );


    elements.deleteModeButton.addEventListener(
        "click",
        toggleDeleteMode
    );


    elements.formatCodeButton.addEventListener(
        "click",
        formatCode
    );


    elements.addArgumentButton.addEventListener(
        "click",
        addArgumentInput
    );


    elements.cancelMyBlock.addEventListener(
        "click",
        closeMyBlockModal
    );


    elements.createMyBlock.addEventListener(
        "click",
        createMyBlock
    );


    elements.cancelBlockEdit.addEventListener(
        "click",
        closeBlockEdit
    );


    elements.saveBlockEdit.addEventListener(
        "click",
        saveBlockEdit
    );


    elements.workspace.addEventListener(
        "dragover",
        workspaceDragOver
    );


    elements.workspace.addEventListener(
        "drop",
        workspaceDrop
    );


    elements.workspace.addEventListener(
        "click",
        workspaceClick
    );

}


/* =========================================================
   CAMBIAR IDIOMA
========================================================= */

function changeLanguage(event) {

    state.language = event.target.value;

    clearWorkspace();

    renderPalette();

    generateCode();

}


/* =========================================================
   PALETA
========================================================= */

function renderPalette() {

    elements.categories.innerHTML = "";

    const language = state.language;

    const languageColor =
        CATEGORY_COLORS[language] || "#888";


    /*
        Categorías principales
    */

    if (language === "html") {

        createCategory(
            "Tags",
            "tags",
            SVG_LIBRARY.html.tags,
            languageColor,
            language
        );

    }


    if (language === "javascript") {

        createCategory(
            "Functions",
            "functions",
            SVG_LIBRARY.javascript.functions,
            CATEGORY_COLORS.functions,
            language
        );

    }


    if (language === "css") {

        createCategory(
            "Groups",
            "groups",
            SVG_LIBRARY.css.groups,
            CATEGORY_COLORS.groups,
            language
        );


        createCategory(
            "Functions",
            "functions",
            SVG_LIBRARY.css.functions,
            CATEGORY_COLORS.cssFunctions,
            language
        );

    }


    /*
        My Blocks existe para todos los lenguajes.
    */

    createMyBlocksCategory();

}


/* =========================================================
   CREAR CATEGORÍA
========================================================= */

function createCategory(
    title,
    category,
    blocks,
    color,
    language
) {

    const categoryElement =
        document.createElement("div");

    categoryElement.className =
        "category";


    const header =
        document.createElement("div");

    header.className =
        "categoryHeader";

    header.style.background =
        color;


    const arrow =
        document.createElement("span");

    arrow.className =
        "categoryArrow";

    arrow.textContent =
        "▼";


    const text =
        document.createElement("span");

    text.textContent =
        title;


    header.appendChild(arrow);
    header.appendChild(text);


    const blocksContainer =
        document.createElement("div");

    blocksContainer.className =
        "categoryBlocks";


    header.addEventListener(
        "click",
        () => {

            const hidden =
                blocksContainer.style.display === "none";

            blocksContainer.style.display =
                hidden ? "flex" : "none";

            arrow.textContent =
                hidden ? "▼" : "▶";

        }
    );


    for (const block of blocks) {

        const paletteBlock =
            createPaletteBlock(
                block,
                language,
                category
            );

        blocksContainer.appendChild(
            paletteBlock
        );

    }


    categoryElement.appendChild(header);

    categoryElement.appendChild(
        blocksContainer
    );

    elements.categories.appendChild(
        categoryElement
    );

}


/* =========================================================
   MY BLOCKS
========================================================= */

function createMyBlocksCategory() {

    const categoryElement =
        document.createElement("div");

    categoryElement.className =
        "category";


    const header =
        document.createElement("div");

    header.className =
        "categoryHeader";

    header.style.background =
        CATEGORY_COLORS.myBlocks;


    const arrow =
        document.createElement("span");

    arrow.className =
        "categoryArrow";

    arrow.textContent =
        "▼";


    const text =
        document.createElement("span");

    text.textContent =
        "My Blocks";


    const add =
        document.createElement("button");

    add.type =
        "button";

    add.textContent =
        "+";

    add.style.marginLeft =
        "auto";

    add.style.width =
        "28px";

    add.style.height =
        "26px";

    add.style.padding =
        "0";

    add.addEventListener(
        "click",
        event => {

            event.stopPropagation();

            openMyBlockModal();

        }
    );


    header.appendChild(arrow);
    header.appendChild(text);
    header.appendChild(add);


    const blocksContainer =
        document.createElement("div");

    blocksContainer.className =
        "categoryBlocks";


    header.addEventListener(
        "click",
        () => {

            const hidden =
                blocksContainer.style.display === "none";

            blocksContainer.style.display =
                hidden ? "flex" : "none";

            arrow.textContent =
                hidden ? "▼" : "▶";

        }
    );


    for (const block of state.myBlocks) {

        const item =
            createMyBlockPaletteItem(block);

        blocksContainer.appendChild(item);

    }


    categoryElement.appendChild(header);

    categoryElement.appendChild(
        blocksContainer
    );

    elements.categories.appendChild(
        categoryElement
    );

}


/* =========================================================
   BLOQUE DE PALETA
========================================================= */

function createPaletteBlock(
    block,
    language,
    category
) {

    const wrapper =
        document.createElement("div");

    wrapper.className =
        "paletteBlock";

    wrapper.draggable =
        true;


    loadSvg(
        getBlockPath(
            language,
            category,
            block.file
        )
    )
    .then(svg => {

        setSvgMetadata(svg, block);

        wrapper.appendChild(svg);

    })
    .catch(error => {

        console.error(
            "No se pudo cargar:",
            block.file,
            error
        );

        wrapper.textContent =
            block.name || block.id;

    });


    wrapper.addEventListener(
        "click",
        () => {

            addBlockToWorkspace(
                block,
                language,
                category
            );

        }
    );


    wrapper.addEventListener(
        "dragstart",
        event => {

            state.dragging = {

                type: "palette",

                block,

                language,

                category

            };


            event.dataTransfer.effectAllowed =
                "copy";

        }
    );


    return wrapper;

}


/* =========================================================
   CARGAR SVG
========================================================= */

async function loadSvg(url) {

    const response =
        await fetch(url);

    if (!response.ok) {

        throw new Error(
            `HTTP ${response.status}: ${url}`
        );

    }


    const text =
        await response.text();


    const parser =
        new DOMParser();


    const documentSvg =
        parser.parseFromString(
            text,
            "image/svg+xml"
        );


    const svg =
        documentSvg.documentElement;


    if (
        !svg ||
        svg.nodeName.toLowerCase() !== "svg"
    ) {

        throw new Error(
            "El archivo no contiene un SVG válido"
        );

    }


    return document.importNode(
        svg,
        true
    );

}


/* =========================================================
   AGREGAR BLOQUE
========================================================= */

async function addBlockToWorkspace(
    block,
    language,
    category,
    x = null,
    y = null
) {

    const id =
        createId();


    const svg =
        await loadSvg(
            getBlockPath(
                language,
                category,
                block.file
            )
        );


    setSvgMetadata(svg, block);


    const workspaceBlock = {

        id,

        sourceId:
            block.id,

        name:
            block.name || block.id,

        file:
            block.file,

        language,

        category,

        action:
            block.action || "",

        options:
            block.options || "",

        dropdowns:
            Number(block.dropdowns || 0),

        isC:
            Boolean(block.isc),

        svg,

        parentId:
            null,

        children: [],

        values:
            createDefaultValues(block),

        element:
            null

    };


    const element =
        document.createElement("div");

    element.className =
        "workspaceBlock";

    element.dataset.blockId =
        id;


    element.draggable =
        true;


    element.appendChild(svg);


    workspaceBlock.element =
        element;


    state.blocks.set(
        id,
        workspaceBlock
    );


    if (x === null) {

        x =
            25 +
            state.blocks.size * 8;

    }


    if (y === null) {

        y =
            25 +
            state.blocks.size * 8;

    }


    element.style.left =
        `${x}px`;

    element.style.top =
        `${y}px`;


    if (workspaceBlock.isC) {

        createCSlot(
            workspaceBlock
        );

    }


    elements.workspace.appendChild(
        element
    );


    setupWorkspaceBlockEvents(
        workspaceBlock
    );


    updateEmptyState();

    generateCode();

    selectBlock(workspaceBlock);


    return workspaceBlock;

}


/* =========================================================
   VALORES POR DEFECTO
========================================================= */

function createDefaultValues(block) {

    const values = [];

    const options =
        parseOptions(
            block.options
        );


    for (
        let i = 0;
        i < Number(block.dropdowns || 0);
        i++
    ) {

        values.push(
            options[0] || ""
        );

    }


    return values;

}


/* =========================================================
   EVENTOS DEL BLOQUE
========================================================= */

function setupWorkspaceBlockEvents(
    block
) {

    const element =
        block.element;


    element.addEventListener(
        "click",
        event => {

            event.stopPropagation();

            if (state.deleteMode) {

                deleteBlock(
                    block.id
                );

                return;

            }


            selectBlock(block);

        }
    );


    element.addEventListener(
        "dblclick",
        event => {

            event.stopPropagation();

            openBlockEdit(
                block
            );

        }
    );


    element.addEventListener(
        "dragstart",
        event => {

            if (state.deleteMode) {

                event.preventDefault();

                return;

            }


            state.dragging = {

                type: "workspace",

                blockId:
                    block.id

            };


            event.dataTransfer.effectAllowed =
                "move";

        }
    );


    element.addEventListener(
        "dragend",
        () => {

            state.dragging =
                null;

        }
    );

}


/* =========================================================
   SLOT DE BLOQUE C
========================================================= */

function createCSlot(block) {

    const container =
        document.createElement("div");

    container.className =
        "cSlot";


    container.addEventListener(
        "dragover",
        event => {

            event.preventDefault();

            container.classList.add(
                "hover"
            );

        }
    );


    container.addEventListener(
        "dragleave",
        () => {

            container.classList.remove(
                "hover"
            );

        }
    );


    container.addEventListener(
        "drop",
        event => {

            event.preventDefault();

            container.classList.remove(
                "hover"
            );

            dropIntoCBlock(
                block,
                event
            );

        }
    );


    block.element.appendChild(
        container
    );

}


/* =========================================================
   DROP EN WORKSPACE
========================================================= */

function workspaceDragOver(event) {

    event.preventDefault();

    event.dataTransfer.dropEffect =
        state.dragging &&
        state.dragging.type === "workspace"
            ? "move"
            : "copy";

}


async function workspaceDrop(event) {

    event.preventDefault();


    const rect =
        elements.workspace.getBoundingClientRect();


    const x =
        event.clientX -
        rect.left +
        elements.workspace.scrollLeft;


    const y =
        event.clientY -
        rect.top +
        elements.workspace.scrollTop;


    if (!state.dragging) {
        return;
    }


    if (
        state.dragging.type ===
        "palette"
    ) {

        await addBlockToWorkspace(

            state.dragging.block,

            state.dragging.language,

            state.dragging.category,

            x,

            y

        );

    }


    if (
        state.dragging.type ===
        "workspace"
    ) {

        const block =
            state.blocks.get(
                state.dragging.blockId
            );


        if (!block) {
            return;
        }


        if (
            isDescendant(
                block.id,
                null
            )
        ) {
            return;
        }


        moveElement(
            block.element,
            x,
            y
        );

    }


    state.dragging =
        null;

}


/* =========================================================
   DROP DENTRO DE C
========================================================= */

function dropIntoCBlock(
    parent,
    event
) {

    if (!state.dragging) {
        return;
    }


    if (
        state.dragging.type ===
        "palette"
    ) {

        addNestedBlock(
            parent,
            state.dragging.block,
            state.dragging.language,
            state.dragging.category
        );

    }


    if (
        state.dragging.type ===
        "workspace"
    ) {

        const child =
            state.blocks.get(
                state.dragging.blockId
            );


        if (!child) {
            return;
        }


        if (
            child.id ===
            parent.id
        ) {
            return;
        }


        if (
            isDescendant(
                parent.id,
                child.id
            )
        ) {
            return;
        }


        moveBlockToParent(
            child,
            parent
        );

    }


    state.dragging =
        null;

}


/* =========================================================
   BLOQUE ANIDADO
========================================================= */

async function addNestedBlock(
    parent,
    block,
    language,
    category
) {

    const child =
        await addBlockToWorkspace(
            block,
            language,
            category,
            0,
            0
        );


    moveBlockToParent(
        child,
        parent
    );

}


/* =========================================================
   MOVER A C
========================================================= */

function moveBlockToParent(
    child,
    parent
) {

    if (
        child.id ===
        parent.id
    ) {
        return false;
    }


    if (
        isDescendant(
            parent.id,
            child.id
        )
    ) {

        return false;

    }


    if (child.parentId) {

        const oldParent =
            state.blocks.get(
                child.parentId
            );


        if (oldParent) {

            oldParent.children =
                oldParent.children.filter(
                    id => id !== child.id
                );

        }

    }


    child.parentId =
        parent.id;


    if (
        !parent.children.includes(
            child.id
        )
    ) {

        parent.children.push(
            child.id
        );

    }


    const slot =
        parent.element.querySelector(
            ".cSlot"
        );


    if (!slot) {
        return false;
    }


    slot.appendChild(
        child.element
    );


    child.element.classList.add(
        "nestedBlock"
    );


    child.element.style.left =
        "12px";


    child.element.style.top =
        `${10 + (parent.children.length - 1) * 45}px`;


    generateCode();

    return true;

}


/* =========================================================
   DESCENDENCIA
========================================================= */

function isDescendant(
    ancestorId,
    targetId
) {

    if (!targetId) {
        return false;
    }


    const ancestor =
        state.blocks.get(
            ancestorId
        );


    if (!ancestor) {
        return false;
    }


    if (
        ancestor.children.includes(
            targetId
        )
    ) {

        return true;

    }


    for (
        const childId
        of ancestor.children
    ) {

        if (
            isDescendant(
                childId,
                targetId
            )
        ) {

            return true;

        }

    }


    return false;

}


/* =========================================================
   MOVER ELEMENTO
========================================================= */

function moveElement(
    element,
    x,
    y
) {

    if (
        element.classList.contains(
            "nestedBlock"
        )
    ) {
        return;
    }


    element.style.left =
        `${Math.max(0, x)}px`;

    element.style.top =
        `${Math.max(0, y)}px`;

}


/* =========================================================
   SELECCIÓN
========================================================= */

function selectBlock(block) {

    if (state.selectedBlock) {

        state.selectedBlock.element
            .classList.remove(
                "selected"
            );

    }


    state.selectedBlock =
        block;


    if (block) {

        block.element
            .classList.add(
                "selected"
            );

    }

}


/* =========================================================
   CLICK WORKSPACE
========================================================= */

function workspaceClick(event) {

    if (
        event.target ===
        elements.workspace
    ) {

        selectBlock(null);

    }

}


/* =========================================================
   MODO ELIMINAR
========================================================= */

function toggleDeleteMode() {

    state.deleteMode =
        !state.deleteMode;


    elements.deleteModeButton.style.background =
        state.deleteMode
            ? "#a83232"
            : "";


    elements.deleteModeButton.textContent =
        state.deleteMode
            ? "✖ Eliminar: ACTIVADO"
            : "🗑 Eliminar";

}


/* =========================================================
   ELIMINAR BLOQUE
========================================================= */

function deleteBlock(id) {

    const block =
        state.blocks.get(id);


    if (!block) {
        return;
    }


    /*
        Primero eliminar hijos.
    */

    for (
        const childId
        of [...block.children]
    ) {

        deleteBlock(
            childId
        );

    }


    /*
        Quitar del padre.
    */

    if (block.parentId) {

        const parent =
            state.blocks.get(
                block.parentId
            );


        if (parent) {

            parent.children =
                parent.children.filter(
                    childId =>
                        childId !== id
                );

        }

    }


    block.element.remove();


    state.blocks.delete(id);


    if (
        state.selectedBlock &&
        state.selectedBlock.id === id
    ) {

        state.selectedBlock =
            null;

    }


    updateEmptyState();

    generateCode();

}


/* =========================================================
   LIMPIAR
========================================================= */

function clearWorkspace() {

    for (
        const block
        of state.blocks.values()
    ) {

        block.element.remove();

    }


    state.blocks.clear();

    state.selectedBlock =
        null;

    updateEmptyState();

    generateCode();

}


/* =========================================================
   ESTADO VACÍO
========================================================= */

function updateEmptyState() {

    elements.workspaceEmpty.style.display =
        state.blocks.size === 0
            ? "block"
            : "none";

}


/* =========================================================
   EDITAR BLOQUE
========================================================= */

function openBlockEdit(block) {

    state.editingBlock =
        block;


    elements.blockEditContent.innerHTML =
        "";


    const options =
        parseOptions(
            block.options
        );


    if (
        block.dropdowns > 0
    ) {

        for (
            let i = 0;
            i < block.dropdowns;
            i++
        ) {

            const label =
                document.createElement(
                    "label"
                );

            label.textContent =
                `Valor ${i + 1}`;


            const select =
                document.createElement(
                    "select"
                );

            select.dataset.index =
                String(i);


            for (
                const option
                of options
            ) {

                const item =
                    document.createElement(
                        "option"
                    );

                item.value =
                    option;

                item.textContent =
                    option;

                select.appendChild(
                    item
                );

            }


            if (
                block.values[i] !==
                undefined
            ) {

                select.value =
                    block.values[i];

            }


            elements.blockEditContent
                .appendChild(
                    label
                );


            elements.blockEditContent
                .appendChild(
                    select
                );

        }

    }
    else {

        const info =
            document.createElement(
                "div"
            );

        info.textContent =
            "Este bloque no tiene menús desplegables.";

        info.style.color =
            "#aaa";

        elements.blockEditContent
            .appendChild(
                info
            );

    }


    elements.blockEditModal
        .classList.remove(
            "hidden"
        );

}


function closeBlockEdit() {

    state.editingBlock =
        null;

    elements.blockEditModal
        .classList.add(
            "hidden"
        );

}


function saveBlockEdit() {

    const block =
        state.editingBlock;


    if (!block) {
        return;
    }


    const selects =
        elements.blockEditContent
            .querySelectorAll(
                "select"
            );


    for (
        const select
        of selects
    ) {

        const index =
            Number(
                select.dataset.index
            );


        block.values[index] =
            select.value;

    }


    closeBlockEdit();

    generateCode();

}


/* =========================================================
   MY BLOCKS - MODAL
========================================================= */

function openMyBlockModal() {

    elements.myBlockName.value =
        "";

    elements.myBlockColor.value =
        "#fc038c";

    elements.myBlockArguments.innerHTML =
        "";

    addArgumentInput();

    elements.myBlockModal
        .classList.remove(
            "hidden"
        );

}


function closeMyBlockModal() {

    elements.myBlockModal
        .classList.add(
            "hidden"
        );

}


/* =========================================================
   ARGUMENTO
========================================================= */

function addArgumentInput() {

    const row =
        document.createElement(
            "div"
        );

    row.className =
        "argumentRow";


    const name =
        document.createElement(
            "input"
        );

    name.type =
        "text";

    name.placeholder =
        "Nombre";


    const type =
        document.createElement(
            "select"
        );


    const number =
        document.createElement(
            "option"
        );

    number.value =
        "number";

    number.textContent =
        "Número";


    const text =
        document.createElement(
            "option"
        );

    text.value =
        "text";

    text.textContent =
        "Texto";


    const boolean =
        document.createElement(
            "option"
        );

    boolean.value =
        "boolean";

    boolean.textContent =
        "Booleano";


    type.appendChild(number);
    type.appendChild(text);
    type.appendChild(boolean);


    const remove =
        document.createElement(
            "button"
        );

    remove.type =
        "button";

    remove.textContent =
        "×";


    remove.addEventListener(
        "click",
        () => {

            row.remove();

        }
    );


    row.appendChild(name);
    row.appendChild(type);
    row.appendChild(remove);


    elements.myBlockArguments
        .appendChild(row);

}


/* =========================================================
   CREAR MY BLOCK
========================================================= */

function createMyBlock() {

    const name =
        elements.myBlockName.value.trim();


    if (!name) {

        alert(
            "Escribe un nombre para el bloque."
        );

        return;

    }


    const color =
        elements.myBlockColor.value;


    const argumentsList =
        [];


    const rows =
        elements.myBlockArguments
            .querySelectorAll(
                ".argumentRow"
            );


    for (
        const row
        of rows
    ) {

        const nameInput =
            row.querySelector(
                "input"
            );

        const typeInput =
            row.querySelector(
                "select"
            );


        const argumentName =
            nameInput.value.trim();


        if (!argumentName) {
            continue;
        }


        argumentsList.push({

            name:
                argumentName,

            type:
                typeInput.value

        });

    }


    const block = {

        id:
            "my_" +
            Date.now(),

        name,

        color,

        arguments:
            argumentsList,

        action:
            "myBlock",

        isc:
            false

    };


    state.myBlocks.push(
        block
    );


    closeMyBlockModal();

    renderPalette();

}


/* =========================================================
   ELEMENTO DE MY BLOCK
========================================================= */

function createMyBlockPaletteItem(
    block
) {

    const wrapper =
        document.createElement(
            "div"
        );

    wrapper.className =
        "paletteBlock";


    const svg =
        createMyBlockSvg(
            block
        );


    wrapper.appendChild(svg);


    wrapper.draggable =
        true;


    wrapper.addEventListener(
        "click",
        () => {

            addMyBlockToWorkspace(
                block
            );

        }
    );


    wrapper.addEventListener(
        "dragstart",
        event => {

            state.dragging = {

                type:
                    "myBlock",

                block

            };


            event.dataTransfer.effectAllowed =
                "copy";

        }
    );


    return wrapper;

}


/* =========================================================
   SVG DE MY BLOCK
========================================================= */

function createMyBlockSvg(block) {

    const svgNS =
        "http://www.w3.org/2000/svg";


    const width =
        Math.max(
            150,
            30 +
            block.name.length * 9 +
            block.arguments.length * 75
        );


    const height =
        38;


    const svg =
        document.createElementNS(
            svgNS,
            "svg"
        );


    svg.setAttribute(
        "width",
        width
    );

    svg.setAttribute(
        "height",
        height
    );

    svg.setAttribute(
        "viewBox",
        `0 0 ${width} ${height}`
    );


    const path =
        document.createElementNS(
            svgNS,
            "path"
        );


    path.setAttribute(
        "d",
        createRoundedBlockPath(
            width,
            height
        )
    );


    path.setAttribute(
        "fill",
        block.color
    );


    path.setAttribute(
        "stroke",
        "rgba(0,0,0,.35)"
    );


    const text =
        document.createElementNS(
            svgNS,
            "text"
        );


    text.setAttribute(
        "x",
        15
    );

    text.setAttribute(
        "y",
        24
    );

    text.setAttribute(
        "fill",
        "white"
    );

    text.setAttribute(
        "font-family",
        "Arial"
    );

    text.setAttribute(
        "font-size",
        "14"
    );

    text.textContent =
        block.name;


    svg.appendChild(path);
    svg.appendChild(text);


    let x =
        20 +
        block.name.length * 8;


    for (
        const argument
        of block.arguments
    ) {

        const rect =
            document.createElementNS(
                svgNS,
                "rect"
            );


        rect.setAttribute(
            "x",
            x
        );

        rect.setAttribute(
            "y",
            8
        );

        rect.setAttribute(
            "width",
            60
        );

        rect.setAttribute(
            "height",
            22
        );

        rect.setAttribute(
            "rx",
            11
        );

        rect.setAttribute(
            "fill",
            "white"
        );


        const argumentText =
            document.createElementNS(
                svgNS,
                "text"
            );


        argumentText.setAttribute(
            "x",
            x + 30
        );

        argumentText.setAttribute(
            "y",
            23
        );

        argumentText.setAttribute(
            "text-anchor",
            "middle"
        );

        argumentText.setAttribute(
            "fill",
            "#555"
        );

        argumentText.setAttribute(
            "font-family",
            "Arial"
        );

        argumentText.setAttribute(
            "font-size",
            "11"
        );

        argumentText.textContent =
            argument.name;


        svg.appendChild(rect);

        svg.appendChild(
            argumentText
        );


        x += 70;

    }


    return svg;

}


function createRoundedBlockPath(
    width,
    height
) {

    const r = 6;


    return `
        M ${r} 0
        H ${width - r}
        Q ${width} 0 ${width} ${r}
        V ${height - r}
        Q ${width} ${height} ${width - r} ${height}
        H ${r}
        Q 0 ${height} 0 ${height - r}
        V ${r}
        Q 0 0 ${r} 0
        Z
    `;

}


/* =========================================================
   AGREGAR MY BLOCK AL WORKSPACE
========================================================= */

async function addMyBlockToWorkspace(
    myBlock
) {

    const id =
        createId();


    const svg =
        createMyBlockSvg(
            myBlock
        );


    svg.dataset.action =
        "myBlock";

    svg.dataset.options =
        "";

    svg.dataset.dropdowns =
        String(
            myBlock.arguments.length
        );

    svg.dataset.isc =
        "false";


    const element =
        document.createElement(
            "div"
        );

    element.className =
        "workspaceBlock";

    element.draggable =
        true;


    element.appendChild(svg);


    const block = {

        id,

        sourceId:
            myBlock.id,

        name:
            myBlock.name,

        file:
            "",

        language:
            state.language,

        category:
            "myBlocks",

        action:
            "myBlock",

        options:
            "",

        dropdowns:
            myBlock.arguments.length,

        isC:
            false,

        svg,

        parentId:
            null,

        children:
            [],

        values:
            myBlock.arguments.map(
                argument =>
                    argument.type ===
                    "boolean"
                        ? "false"
                        : ""
            ),

        myBlock,

        element

    };


    element.dataset.blockId =
        id;


    element.style.left =
        `${25 + state.blocks.size * 8}px`;

    element.style.top =
        `${25 + state.blocks.size * 8}px`;


    state.blocks.set(
        id,
        block
    );


    elements.workspace.appendChild(
        element
    );


    setupWorkspaceBlockEvents(
        block
    );


    updateEmptyState();

    generateCode();

    selectBlock(block);

}


/* =========================================================
   GENERACIÓN DE CÓDIGO
========================================================= */

function generateCode() {

    let code = "";


    const roots =
        getRootBlocks();


    for (
        const block
        of roots
    ) {

        code +=
            generateBlockCode(
                block,
                0
            );

    }


    elements.codeOutput.textContent =
        code.trim();

}


/* =========================================================
   BLOQUES RAÍZ
========================================================= */

function getRootBlocks() {

    const blocks =
        [...state.blocks.values()]
            .filter(
                block =>
                    !block.parentId
            );


    blocks.sort(
        (a, b) => {

            const ay =
                parseFloat(
                    a.element.style.top
                ) || 0;

            const by =
                parseFloat(
                    b.element.style.top
                ) || 0;


            if (ay !== by) {
                return ay - by;
            }


            const ax =
                parseFloat(
                    a.element.style.left
                ) || 0;

            const bx =
                parseFloat(
                    b.element.style.left
                ) || 0;


            return ax - bx;

        }
    );


    return blocks;

}


/* =========================================================
   GENERAR BLOQUE
========================================================= */

function generateBlockCode(
    block,
    depth
) {

    const indent =
        "    ".repeat(depth);


    if (
        block.language ===
        "html"
    ) {

        return generateHtmlBlock(
            block,
            depth
        );

    }


    if (
        block.language ===
        "javascript"
    ) {

        return generateJavascriptBlock(
            block,
            depth
        );

    }


    if (
        block.language ===
        "css"
    ) {

        return generateCssBlock(
            block,
            depth
        );

    }


    return "";

}


/* =========================================================
   HTML
========================================================= */

function generateHtmlBlock(
    block,
    depth
) {

    const indent =
        "    ".repeat(depth);


    if (
        block.action ===
        "html"
    ) {

        /*
            Bloque C HTML.
            Los hijos se colocan dentro del elemento.
        */

        const children =
            block.children
                .map(
                    childId => {

                        const child =
                            state.blocks.get(
                                childId
                            );

                        return child
                            ? generateBlockCode(
                                child,
                                depth + 1
                            )
                            : "";

                    }
                )
                .join("");


        return (
            `${indent}<html>\n` +
            `${indent}${children}` +
            `${indent}</html>\n`
        );

    }


    return "";

}


/* =========================================================
   JAVASCRIPT
========================================================= */

function generateJavascriptBlock(
    block,
    depth
) {

    const indent =
        "    ".repeat(depth);


    if (
        block.action ===
        "setTypeTo"
    ) {

        const value =
            block.values[0] ||
            "const";


        return (
            `${indent}${value} variable = null;\n`
        );

    }


    if (
        block.action ===
        "myBlock"
    ) {

        const args =
            block.myBlock
                ? block.myBlock.arguments
                    .map(
                        argument =>
                            argument.name
                    )
                    .join(", ")
                : "";


        const children =
            block.children
                .map(
                    childId => {

                        const child =
                            state.blocks.get(
                                childId
                            );

                        return child
                            ? generateBlockCode(
                                child,
                                depth + 1
                            )
                            : "";

                    }
                )
                .join("");


        return (
            `${indent}function ${block.name}(${args}) {\n` +
            `${children}` +
            `${indent}}\n`
        );

    }


    return "";

}


/* =========================================================
   CSS
========================================================= */

function generateCssBlock(
    block,
    depth
) {

    const indent =
        "    ".repeat(depth);


    if (
        block.action ===
        "cssGroup"
    ) {

        const selector =
            block.selector ||
            "*";


        const children =
            block.children
                .map(
                    childId => {

                        const child =
                            state.blocks.get(
                                childId
                            );

                        return child
                            ? generateBlockCode(
                                child,
                                depth + 1
                            )
                            : "";

                    }
                )
                .join("");


        return (
            `${indent}${selector} {\n` +
            `${children}` +
            `${indent}}\n`
        );

    }


    return "";

}


/* =========================================================
   FORMATEAR
========================================================= */

function formatCode() {

    const code =
        elements.codeOutput.textContent;


    if (!code.trim()) {
        return;
    }


    const lines =
        code.split("\n");


    let level = 0;


    const result = [];


    for (
        let line
        of lines
    ) {

        line =
            line.trim();


        if (!line) {
            continue;
        }


        if (
            line.startsWith("}") ||
            line.startsWith("</")
        ) {

            level =
                Math.max(
                    0,
                    level - 1
                );

        }


        result.push(
            "    ".repeat(level) +
            line
        );


        if (
            line.endsWith("{") ||
            line.startsWith("<") &&
            !line.startsWith("</") &&
            line.endsWith(">")
        ) {

            level++;

        }

    }


    elements.codeOutput.textContent =
        result.join("\n");

}


/* =========================================================
   COPIAR
========================================================= */

async function copyCode() {

    const code =
        elements.codeOutput.textContent;


    if (!code) {
        return;
    }


    try {

        await navigator.clipboard.writeText(
            code
        );


        const oldText =
            elements.copyButton.textContent;


        elements.copyButton.textContent =
            "Copiado";


        setTimeout(
            () => {

                elements.copyButton.textContent =
                    oldText;

            },
            1000
        );

    }
    catch (error) {

        console.error(
            error
        );

    }

}


/* =========================================================
   SOPORTE PARA DRAG DESDE MY BLOCKS
========================================================= */

elements.workspace.addEventListener(
    "drop",
    async event => {

        /*
            Este listener complementa el drop
            principal para los bloques creados
            por el usuario.
        */

        if (
            !state.dragging ||
            state.dragging.type !==
            "myBlock"
        ) {
            return;
        }


        event.preventDefault();


        const rect =
            elements.workspace
                .getBoundingClientRect();


        const x =
            event.clientX -
            rect.left +
            elements.workspace.scrollLeft;


        const y =
            event.clientY -
            rect.top +
            elements.workspace.scrollTop;


        const block =
            state.dragging.block;


        await addMyBlockToWorkspace(
            block
        );


        const roots =
            getRootBlocks();


        const last =
            roots[roots.length - 1];


        if (last) {

            moveElement(
                last.element,
                x,
                y
            );

        }


        state.dragging =
            null;

    },
    true
);


/* =========================================================
   DOBLE CLICK GENERAL
========================================================= */

elements.workspace.addEventListener(
    "dblclick",
    event => {

        const element =
            event.target.closest(
                ".workspaceBlock"
            );


        if (!element) {
            return;
        }


        const id =
            element.dataset.blockId;


        const block =
            state.blocks.get(id);


        if (block) {

            openBlockEdit(
                block
            );

        }

    }
);


/* =========================================================
   ARRASTRE MANUAL
========================================================= */

/*
    Permite mover bloques con el mouse incluso
    si el navegador no conserva correctamente
    el desplazamiento de drag & drop.
*/

let manualDrag = null;


elements.workspace.addEventListener(
    "mousedown",
    event => {

        if (
            state.deleteMode
        ) {
            return;
        }


        const element =
            event.target.closest(
                ".workspaceBlock"
            );


        if (!element) {
            return;
        }


        if (
            element.classList.contains(
                "nestedBlock"
            )
        ) {
            return;
        }


        const id =
            element.dataset.blockId;


        const block =
            state.blocks.get(id);


        if (!block) {
            return;
        }


        const rect =
            element.getBoundingClientRect();


        manualDrag = {

            block,

            offsetX:
                event.clientX -
                rect.left,

            offsetY:
                event.clientY -
                rect.top

        };


        selectBlock(block);

    }
);


document.addEventListener(
    "mousemove",
    event => {

        if (!manualDrag) {
            return;
        }


        const rect =
            elements.workspace
                .getBoundingClientRect();


        const x =
            event.clientX -
            rect.left +
            elements.workspace.scrollLeft -
            manualDrag.offsetX;


        const y =
            event.clientY -
            rect.top +
            elements.workspace.scrollTop -
            manualDrag.offsetY;


        moveElement(
            manualDrag.block.element,
            x,
            y
        );

    }
);


document.addEventListener(
    "mouseup",
    () => {

        manualDrag =
            null;

    }
);


/* =========================================================
   PREVENIR DRAG DE IMÁGENES
========================================================= */

document.addEventListener(
    "dragstart",
    event => {

        if (
            event.target.tagName ===
            "IMG"
        ) {

            event.preventDefault();

        }

    }
);


/* =========================================================
   CERRAR MODALES CON ESC
========================================================= */

document.addEventListener(
    "keydown",
    event => {

        if (
            event.key !==
            "Escape"
        ) {
            return;
        }


        elements.myBlockModal
            .classList.add(
                "hidden"
            );


        elements.blockEditModal
            .classList.add(
                "hidden"
            );


        state.editingBlock =
            null;

    }
);